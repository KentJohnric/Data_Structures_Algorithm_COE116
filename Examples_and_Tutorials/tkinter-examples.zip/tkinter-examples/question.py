import Tkinter
import tkMessageBox
 
result = tkMessageBox.askyesno("Python","Would you like to save the data?")
print result
