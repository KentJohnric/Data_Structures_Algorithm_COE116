import Tkinter
import tkMessageBox
 
tkMessageBox.showinfo("Title", "a Tk MessageBox")
