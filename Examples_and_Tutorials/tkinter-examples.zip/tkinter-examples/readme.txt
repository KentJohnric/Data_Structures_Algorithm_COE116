required: Python 2.7.9
more: https://pythonspot.com

