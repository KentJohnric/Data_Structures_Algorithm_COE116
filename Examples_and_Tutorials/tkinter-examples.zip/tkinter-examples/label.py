from Tkinter import *
 
root = Tk()
root.title('Python Tk Examples @ pythonspot.com')
Label(root, text='Python').pack(pady=20,padx=50)
 
root.mainloop()
