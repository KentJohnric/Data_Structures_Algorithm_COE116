import Tkinter
import tkMessageBox
 
# An error box
tkMessageBox.showerror("Error","No disk space left on device")
 
# A warning box 
tkMessageBox.showwarning("Warning","Could not start service")
 
# An information box
tkMessageBox.showinfo("Information","Created in Python.")
